from django.contrib import admin
from CalorieApp.models import*
# Register your models here.

admin.site.register(CustomUser)
admin.site.register(ProfileModel)
admin.site.register(CalorieModel)