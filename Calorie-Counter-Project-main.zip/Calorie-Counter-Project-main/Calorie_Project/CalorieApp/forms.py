from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

from CalorieApp.models import*


class RegistrationForm(UserCreationForm):

    class Meta:
        model = CustomUser
        fields = [
            'username',
            'email',
            'password1',
            'password2',
        ]


class ProfileForm(forms.ModelForm):

    class Meta:
        model = ProfileModel

        fields = [
            'name',
            'age',
            'gender',
            'height',
            'weight',
        ]

        widgets = {
            'age': forms.NumberInput(
                attrs={'placeholder': 'Age'}
            ),

            'height': forms.NumberInput(
                attrs={'placeholder': 'Height in cm'}
            ),

            'weight': forms.NumberInput(
                attrs={'placeholder': 'Weight in kg'}
            ),
        }


class CalorieForm(forms.ModelForm):

    class Meta:
        model = CalorieModel

        fields = [
            'item_name',
            'calorie_consumed',
        ]

        widgets = {
            'item_name': forms.TextInput(
                attrs={
                    'placeholder': 'Food Item'
                }
            ),

            'calorie_consumed': forms.NumberInput(
                attrs={
                    'placeholder': 'Calories'
                }
            ),
        }