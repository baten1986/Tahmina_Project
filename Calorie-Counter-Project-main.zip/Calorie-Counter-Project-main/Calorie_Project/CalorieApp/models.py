from django.db import models
from django.contrib.auth.models import AbstractUser

class CustomUser(AbstractUser):

    def __str__(self):
        return self.username


class ProfileModel(models.Model):

    GENDER_CHOICES = (
        ('Male', 'Male'),
        ('Female', 'Female'),
    )

    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)

    name = models.CharField(max_length=100)
    age = models.IntegerField()
    gender = models.CharField(
        max_length=10,
        choices=GENDER_CHOICES,
        
    )
    height = models.FloatField(default=0)
    weight = models.FloatField(default=0)

    required_calories = models.FloatField(default=0)

    def __str__(self):
        return self.name


class CalorieModel(models.Model):

    user = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE
    )

    item_name = models.CharField(max_length=100)

    calorie_consumed = models.FloatField(default=0)

    date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.item_name