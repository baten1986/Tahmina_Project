from django.urls import path

from CalorieApp.views import*


urlpatterns = [

    path(
        '',
        DashboardPage,
        name='DashboardPage'
    ),

    path(
        'register/',
        RegistrationPage,
        name='RegistrationPage'
    ),

    path(
        'login/',
        LoginPage,
        name='LoginPage'
    ),

    path(
        'logout/',
        LogoutPage,
        name='LogoutPage'
    ),

    path(
        'profile/',
        ProfilePage,
        name='ProfilePage'
    ),

    path(
        'add-calorie/',
        AddCaloriePage,
        name='AddCaloriePage'
    ),

    path(
    'delete-calorie/<int:id>/',
    DeleteCaloriePage,
    name='DeleteCaloriePage'
),
]