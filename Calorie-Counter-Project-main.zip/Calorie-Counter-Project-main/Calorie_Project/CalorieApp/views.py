from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from django.contrib.auth.models import User
from django.db.models import Sum

from django.utils import timezone

from CalorieApp.models import*
from CalorieApp.forms import*


def RegistrationPage(request):

    form = RegistrationForm()

    if request.method == 'POST':

        form = RegistrationForm(request.POST)

        if form.is_valid():

            user = form.save()

            login(request, user)

            return redirect('ProfilePage')

    context = {
        'form': form
    }

    return render(
        request,
        'register.html',
        context
    )


def LoginPage(request):

    if request.method == 'POST':

        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:

            login(request, user)

            return redirect('DashboardPage')

        else:

            messages.error(
                request,
                'Invalid username or password'
            )

    return render(
        request,
        'login.html'
    )


@login_required
def LogoutPage(request):

    logout(request)

    return redirect('LoginPage')


@login_required
def ProfilePage(request):

    try:
        profile = ProfileModel.objects.get(
            user=request.user
        )

    except ProfileModel.DoesNotExist:

        profile = None


    form = ProfileForm(
        instance=profile
    )


    if request.method == 'POST':

        form = ProfileForm(
            request.POST,
            instance=profile
        )

        if form.is_valid():

            profile = form.save(
                commit=False
            )

            profile.user = request.user


            age = profile.age
            weight = profile.weight
            height = profile.height
            gender = profile.gender


            if gender == 'Male':

                bmr = (
                    66.47
                    + (13.75 * weight)
                    + (5.003 * height)
                    - (6.755 * age)
                )

            else:

                bmr = (
                    655.1
                    + (9.563 * weight)
                    + (1.850 * height)
                    - (4.676 * age)
                )


            profile.required_calories = round(
                bmr,
                2
            )

            profile.save()

            return redirect('DashboardPage')


    context = {
        'form': form,
        'profile': profile
    }

    return render(
        request,
        'profile.html',
        context
    )
@login_required
def AddCaloriePage(request):

    form = CalorieForm()

    if request.method == 'POST':

        form = CalorieForm(request.POST)

        if form.is_valid():

            calorie = form.save(commit=False)

            calorie.user = request.user

            calorie.save()

            return redirect('DashboardPage')

    context = {
        'form': form
    }

    return render(
        request,
        'add_calorie.html',
        context
    )

@login_required
def DashboardPage(request):

    try:
        profile = ProfileModel.objects.get(
            user=request.user
        )
    except ProfileModel.DoesNotExist:
        return redirect('ProfilePage')

    calories = CalorieModel.objects.filter(
        user=request.user
    )

    consumed = calories.aggregate(
        total=Sum('calorie_consumed')
    )['total'] or 0

    remaining = profile.required_calories - consumed

    context = {
        'profile': profile,
        'calories': calories,
        'consumed': consumed,
        'remaining': remaining,
    }

    return render(
        request,
        'dashboard.html',
        context
    )

@login_required
def DeleteCaloriePage(request, id):

    calorie = CalorieModel.objects.get(
        id=id,
        user=request.user
    )

    calorie.delete()

    return redirect('DashboardPage')