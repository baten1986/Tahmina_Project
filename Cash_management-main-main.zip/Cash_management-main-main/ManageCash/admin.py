from django.contrib import admin
from ManageCash.models import*

# Register your models here.
admin.site.register([CustomUserModel, AddCash_Model, Expense_Model,Transaction_Model])
