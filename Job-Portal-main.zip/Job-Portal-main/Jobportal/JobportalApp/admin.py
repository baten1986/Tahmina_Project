from django.contrib import admin
from .models import *


admin.site.register(JobPostModel)
# Register your models here.
