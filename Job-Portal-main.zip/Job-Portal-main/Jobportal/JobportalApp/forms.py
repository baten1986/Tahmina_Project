from django import forms
from .models import *
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm

class RegisterForm(UserCreationForm):
    class Meta:
        model = UserModel
        fields = ['username', 'email', 'user_type', 'password1', 'password2']


    
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for i_name,i in self.fields.items():
            i.widget.attrs['class']='form-control'


class AuthForm(AuthenticationForm):
    class Meta:
        model = UserModel
        fields = ['username', 'password']
    
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for i_name,i in self.fields.items():
            i.widget.attrs['class']='form-control'


class JobSeekerForm(forms.ModelForm):
    class Meta:
        model = JobSeekerProfile
        fields = '__all__'
        exclude = ['user']
    
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for i_name,i in self.fields.items():
            i.widget.attrs['class']='form-control'

class RecruitrForm(forms.ModelForm):
    class Meta:
        model = RecruiterProfile
        fields = '__all__'
        exclude = ['user']
    
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for i_name,i in self.fields.items():
            i.widget.attrs['class']='form-control'

class JobPostForm(forms.ModelForm):
    class Meta:
        model = JobPostModel
        fields = '__all__'
        exclude = ['recruiter']
    
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for i_name,i in self.fields.items():
            i.widget.attrs['class']='form-control'

class SkillForm(forms.ModelForm):
    class Meta:
        model = SkillModel
        fields = '__all__'
    
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for i_name,i in self.fields.items():
            i.widget.attrs['class']='form-control'
    

    