from django.db import models
from django.contrib.auth.models import AbstractUser

class UserModel(AbstractUser):
    USERType = [
        ('JobSeeker', 'JobSeeker'),
        ('Recruiter', 'Recruiter'),
    ]

    user_type= models.CharField(choices=USERType, max_length=20)

    def __str__(self):
        return self.username


class SkillModel(models.Model):
    name = models.CharField(max_length=50, unique=True, null=True)

    def __str__(self):
        return self.name

class JobSeekerProfile(models.Model):
    user = models.OneToOneField(UserModel, on_delete=models.CASCADE)
    name = models.CharField(max_length=20, null=True)
    phone = models.CharField(max_length=20, null=True)
    skill_set = models.ManyToManyField(SkillModel, null=True)
    resume = models.FileField(upload_to='media/resume', null=True)

    def __str__(self):
        return self.name
    
class RecruiterProfile(models.Model):
    user = models.OneToOneField(UserModel, on_delete=models.CASCADE)
    name = models.CharField(max_length=20, null=True)
    phone = models.CharField(max_length=20, null=True)
    company = models.CharField(max_length=20, null=True)
    address = models.CharField(max_length=20, null=True)


    def __str__(self):
        return self.name


class JobPostModel(models.Model):
    recruiter = models.ForeignKey(RecruiterProfile, on_delete=models.SET_NULL, null=True)
    title = models.CharField(max_length=50, null=True)
    description = models.TextField(null=True)
    number_of_openings = models.PositiveIntegerField( null=True)
    skill_set = models.ManyToManyField(SkillModel, null=True)
    category = models.CharField(max_length=50, null=True)
    image = models.ImageField(upload_to='media/jobs',  null=True)

   


class ApplyModel(models.Model):
    Status = [
        ('Pending','Pending'),
        ('Short-Listed','Short-Listed'),
        ('Rejected','Rejected'),
    ]
    seeker = models.ForeignKey(JobSeekerProfile, on_delete=models.CASCADE, null=True)
    job = models.ForeignKey(JobPostModel, on_delete=models.CASCADE, null=True)
    status = models.CharField(choices=Status, null=True, max_length=20)



