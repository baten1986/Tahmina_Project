from django.urls import path
from .views import *

urlpatterns = [
    path('', loginPage, name='login'),
    path('register/', registerPage, name='register'),
    path('logout/', logoutPage, name='logout'),
    path('dashboard/', dashboardPage, name='dashboard'),
    path('seeker/', jobSeekerPage, name='seeker'),
    path('recruiter/', recruiterPage, name='recruiter'),
    path('jobPost/', jobPostPage, name='jobPost'),
    path('applicants/', applicantsListPage, name='applicants'),
    path('myApplication/', myApplicationPage, name='myApplication'),
    path('apply/<int:id>/', applyPage, name='apply'),
    path('skillAdd/', skillAddPage, name='skillAdd'),
    path('shortisted/<int:id>/', shortistedPage, name='shortisted'),
    path('reject/<int:id>/', rejectPage, name='reject'),
    path('myJob/', myJobPage, name='myJob')

]
