from django.shortcuts import render, redirect
from .forms import *
from .models import *
from django.contrib.auth import login, logout
from django.http import HttpResponse



def registerPage(request):

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            if user:
                login(request, user)
                return redirect('dashboard')

    form = RegisterForm()
    context = {
        'form': form,
        'title':'Create Account',
        'btn':'Create',
    }
    return render(request, 'pages/baseForm.html',context)

def loginPage(request):

    if request.method == 'POST':
        form = AuthForm(request,request.POST)
        if form.is_valid():
            user = form.get_user()
            if user:
                login(request, user)
                return redirect('dashboard')


    form = AuthForm()
    context = {
        'form': form,
        'title':'Login Account',
        'btn':'Login',
    }
    return render(request, 'pages/baseForm.html',context)


def dashboardPage(request):

    if request.user.user_type == 'Recruiter':
        jobs = JobPostModel.objects.filter(recruiter__user = request.user)
    
    else:
        jobs = JobPostModel.objects.all() 
        



   
    context = {
        'job':jobs
    }
    return render(request, 'pages/dashboard.html',context)

def logoutPage(request):
    logout(request)
    return redirect('login')


def jobSeekerPage(request):
    try:
        user = JobSeekerProfile.objects.get(user = request.user)
    except JobSeekerProfile.DoesNotExist:
        user = JobSeekerProfile.objects.create(user = request.user)
    

    if request.method == 'POST':
        form = JobSeekerForm(request.POST, request.FILES, instance = user)
        if form.is_valid():
            form.save()         
                
            return redirect('dashboard')
    form = JobSeekerForm(instance = user)
    context = {
        'form': form,
        'title':'Update Profile',
        'btn':'Update',
    }
    return render(request, 'pages/baseForm.html',context)

def recruiterPage(request):
    try:
        user = RecruiterProfile.objects.get(user = request.user)
    except RecruiterProfile.DoesNotExist:
        user = RecruiterProfile.objects.create(user = request.user)
    

    if request.user.user_type == 'Recruiter':
        if request.method == 'POST':
                form = RecruitrForm(request.POST, request.FILES, instance = user)
                if form.is_valid():
                    form.save()             
                    return redirect('dashboard')
            
            
        form = RecruitrForm(instance = user)
        context = {
            'form': form,
            'title':'Update Profile',
            'btn':'Update',
        }
    else:
        return HttpResponse("404 Page Not Found")
    return render(request, 'pages/baseForm.html',context)


def jobPostPage(request):
    try:
        recruiter = RecruiterProfile.objects.get(user = request.user)
    except RecruiterProfile.DoesNotExist:
        return redirect('recruiter')

    if request.method == 'POST':
        form = JobPostForm(request.POST, request.FILES)
        if form.is_valid():
            data = form.save(commit=False)
            data.recruiter = recruiter
            data.save() 
            form.save_m2m()          
            return redirect('dashboard')
    
    
    form = JobPostForm()
    context = {
        'form': form,
        'title':'Post A New Job',
        'btn':'Post',
    }
    return render(request, 'pages/baseForm.html',context)


def applyPage(request,id):
    try:
        seeker = JobSeekerProfile.objects.get(user = request.user)
    except JobSeekerProfile.DoesNotExist:
        return redirect('seeker')
    
    job = JobPostModel.objects.get(id=id)

    ApplyModel.objects.create(
        seeker = seeker,
        job = job,
        status = 'Pending'
    )

    return redirect('myApplication')

def applicantsListPage(request):


    applicants = ApplyModel.objects.filter(job__recruiter__user = request.user)
    context = {
        'applicants':applicants
    }
    return render(request, 'pages/applicantsList.html',context)

def myApplicationPage(request):

    seeker = JobSeekerProfile.objects.get(user = request.user)
    myApplications = ApplyModel.objects.filter(seeker = seeker)

    context={
        'myApplications': myApplications
    }


    return render(request, 'pages/myApplications.html',context)

def shortistedPage(request,id):

    get_application = ApplyModel.objects.get(id=id)

    get_application.status = 'Short-Listed'

    get_application.save()
    return redirect('applicants')

def rejectPage(request, id):
    get_application = ApplyModel.objects.get(id=id)

    get_application.status = 'Rejected'

    get_application.save()

    return redirect('applicants')

def skillAddPage(request):


    if request.method == 'POST':
        form = SkillForm(request.POST)
        if form.is_valid():
            form.save()

    form = SkillForm()
    context = {
        'form': form,
        'title':'Add Skill',
        'btn':'Add',
    }
    return render(request,'pages/baseForm.html',context)

def myJobPage(request):

    seeker = JobSeekerProfile.objects.get(user = request.user)

    if seeker:
        skills = seeker.skill_set.all()

    matching_job = JobPostModel.objects.filter(skill_set__in = skills).distinct()

    context = {
        'matching_job':matching_job
    }

    return render(request, 'pages/myJob.html',context)