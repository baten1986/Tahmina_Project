from django.contrib import admin

from PortfolioApp.models import*
# Register your models here.
admin.site.register(CustomUser)
admin.site.register(Profile)
admin.site.register(Education)
admin.site.register(Skill)
admin.site.register(Project)
admin.site.register(Experience)
admin.site.register(Contact)