from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from PortfolioApp.models import*

class RegistrationForm(UserCreationForm):
    class Meta:

        model = CustomUser

        fields = ['username','email','password1','password2']

class LoginForm(AuthenticationForm):
    pass

# Profile Form
class ProfileForm(forms.ModelForm):

    class Meta:
        model = Profile
        fields = '__all__'



# Education Form
class EducationForm(forms.ModelForm):

    class Meta:
        model = Education
        fields = '__all__'



# Skill Form
class SkillForm(forms.ModelForm):

    class Meta:
        model = Skill
        fields = '__all__'



# Project Form
class ProjectForm(forms.ModelForm):

    class Meta:
        model = Project
        fields = '__all__'



# Experience Form
class ExperienceForm(forms.ModelForm):

    class Meta:
        model = Experience
        fields = '__all__'



# Contact Form
class ContactForm(forms.ModelForm):

    class Meta:
        model = Contact
        fields = '__all__'