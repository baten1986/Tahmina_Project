from django.urls import path
from PortfolioApp.views import*


urlpatterns = [

    path('',home,name='home'),

    path('login/',loginPage,name='loginPage'),

    path('register/',registerPage,name='registerPage'),

    path('dashboard/',dashboard,name='dashboard'),

    path('resume/',resume,name='resume'),

    path('contact/',contact,name='contact'),


]

