from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

from PortfolioApp.models import*
from PortfolioApp.forms import*


# Home Page
def home(request):

    profile = Profile.objects.first()

    skills = Skill.objects.all()

    projects = Project.objects.all()

    education = Education.objects.all()

    experience = Experience.objects.all()



    context = {

        'profile': profile,

        'skills': skills,

        'projects': projects,

        'education': education,

        'experience': experience,

    }


    return render(request,'home.html',context)

# Registration Page

def registerPage(request):

    form = RegistrationForm()


    if request.method == "POST":

        form = RegistrationForm(request.POST)


        if form.is_valid():

            user = form.save()

            login(request,user)

            return redirect('dashboard')



    context = {
        'form':form
    }


    return render(request,'register.html',context)


# Login Page
def loginPage(request):

    form = LoginForm(request=request)


    if request.method == "POST":

        form = LoginForm(
            request=request,
            data=request.POST
        )


        if form.is_valid():

            user = form.get_user()

            login(
                request,
                user
            )

            return redirect('dashboard')



    context = {
        'form':form
    }


    return render(request,'login.html',context)

# dashborad
def dashboard(request):

    profile = Profile.objects.first()

    total_skill = Skill.objects.count()

    total_project = Project.objects.count()

    total_education = Education.objects.count()

    total_experience = Experience.objects.count()



    context = {

        'profile': profile,

        'total_skill': total_skill,

        'total_project': total_project,

        'total_education': total_education,

        'total_experience': total_experience,

    }


    return render(request,'dashboard.html',context)

# Resume / CV Page
def resume(request):

    profile = Profile.objects.first()

    education = Education.objects.all()

    experience = Experience.objects.all()

    skills = Skill.objects.all()



    context = {

        'profile': profile,

        'education': education,

        'experience': experience,

        'skills': skills,

    }


    return render(request,'resume.html',context)


# Contact Page
def contact(request):

    form = ContactForm()


    if request.method == "POST":

        form = ContactForm(request.POST)


        if form.is_valid():

            form.save()


            messages.success(
                request,
                "Your message has been sent successfully!"
            )


            return redirect('contact')



    context = {

        'form':form

    }


    return render(request,'contact.html',context)

